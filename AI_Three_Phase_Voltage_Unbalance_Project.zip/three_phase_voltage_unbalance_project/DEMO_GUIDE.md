# Demonstration checklist

## Before the demo
- [ ] `pip install -r requirements.txt`
- [ ] `python train_model.py`
- [ ] Confirm `outputs/metrics.json` exists.
- [ ] Start `streamlit run app.py`.

## Demo flow (3–5 minutes)
1. Explain the R, Y and B phase voltage inputs.
2. Enter 230, 230, 230 V and show the calculated unbalance and prediction.
3. Change the values to 230, 225, 218 V and discuss the change.
4. Open the unseen test data tab and click Predict unseen dataset.
5. Show the generated confusion-matrix images and `outputs/metrics.json`.
6. Explain that all provided data are synthetic and thresholds illustrative.

## Viva points
- Why calculate average voltage? To form a reference for phase deviation.
- Why use two models? To compare classification performance rather than assume one is best.
- Why use F1-score? It balances precision and recall, useful when class counts differ.
- What is the key limitation? Synthetic labels/data do not prove performance on actual electrical systems.
- How can safety be improved? Use calibrated, isolated, appropriately rated measurement hardware and qualified supervision.
