# AI-Based Three-Phase Voltage Unbalance Detection and Severity Classification

## Project overview
This educational prototype calculates a voltage-unbalance percentage from three phase-to-neutral RMS voltage readings and classifies the severity using machine learning.

## Important engineering note
The included data are synthetic, generated for demonstration. Thresholds are configurable and illustrative:
- Balanced: <= 1.0%
- Mildly Unbalanced: > 1.0% and <= 2.0%
- Severely Unbalanced: > 2.0%

The implemented metric is maximum phase deviation from the average, divided by the average, multiplied by 100. Some standards and utilities use different definitions (for example, negative-sequence voltage / positive-sequence voltage). Confirm the required definition and limits with your supervisor/standard before making real-world claims.

## Run
1. Install Python 3.10 or newer.
2. Open a terminal in this folder.
3. Create an environment (optional): `python -m venv .venv`
4. Activate it and install dependencies: `pip install -r requirements.txt`
5. Train models: `python train_model.py`
6. Start dashboard: `streamlit run app.py`

## Files
- `data/voltage_unbalance_dataset.csv`: synthetic training/evaluation dataset
- `data/unseen_test_data.csv`: separate synthetic demo dataset
- `train_model.py`: preprocessing, training, evaluation, metrics and saved models
- `app.py`: Streamlit dashboard with manual input and unseen-data testing
- `requirements.txt`: Python dependencies
- `project_report.docx`: project report
- `presentation.pptx`: presentation
